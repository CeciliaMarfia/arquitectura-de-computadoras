.data
a: .double 1.3, 3.5, 5.8, 1.9, 2.7
b: .double 7.1, 3.4, 9.0, 1.0, 5.8
c: .double 2.3, 8.2, 0.5, 1.1, 2.9
res: .double 0.0, 0.0, 0.0, 0.0, 0.0

.code
daddi $s0, $zero, 5 ; $s0 = cantidad de elementos

; Preparo los parametros
daddi $a0, $zero, a ; $a0 = direccion de a
daddi $a1, $zero, b ; $a1 = direccion de b
daddi $a2, $zero, c ; $a2 = direccion de c
daddi $a3, $zero, res ; $a3 = direccion de res

loop: jal calcular
    daddi $s0, $s0, -1 ; Decremento la cantidad de elementos a calcular
    ; Actualizo los parametros
    daddi $a0, $a0, 8 ; Actualizo direccion de a
    daddi $a1, $a1, 8 ; Actualizo direccion de b
    daddi $a2, $a2, 8 ; Actualizo direccion de c
    daddi $a3, $a3, 8 ; Actualizo direccion de res
    bnez $s0, loop; Mientras $s0 no sea 0, itero
halt

calcular: l.d f1, 0($a0) ; Tomo el primer elemento (a)
    l.d f2, 0($a1) ; Tomo el segundo elemento (b)
    l.d f3, 0($a2) ; Tomo el tercer elemento (c)
    sub.d f5, f1, f3 ; f5 = a - c
    mul.d f2, f2, f2 ; b ^ 2
    div.d f4, f5, f2 ; (a - c) / b ^ 2
    s.d f4, 0($a3) ; Guardo el resultado en memoria
    jr r31 ; Vuelvo