.data
s: .double 1
m: .double 2

.code
add.d f14, f2, f8
mul.d f16, f2, f8
s.d f14, s(r0)
s.d f16, m(r0)

halt