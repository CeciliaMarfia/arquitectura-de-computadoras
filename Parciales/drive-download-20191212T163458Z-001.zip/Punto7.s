.data
control: .word32 0x10000
data: .word32 0x10008
color: .byte 5, 0, 0, 0

.code
lwu r24, data(r0)
lwu r25, control(r0)
daddi r2, r0, 5 ; Para mandar a CONTROL
daddi r10, r0, 0
daddi r20, r0, 49
lwu r8, color(r0)
dadd r9, r0, r0
salto3: sw r9, 0(r24) ; Mando color a DATA
    sb r10, 4(r24) ; Manda coordenada Y a DATA (linea)
    daddi r11, r0, 49
salto2: sb r11, 5(r24) ; Manda coordenada X a DATA (columna)
    sd r2, 0(r25) ; Manda 5 a CONTROL para pintar el pixel
    beqz r11, salto1
    daddi r11, r11, -1
    j salto2
salto1: beq r10, r20, salto4
    daddi r10, r10, 1 ; Actualizo linea
    dadd r9, r9, r8 ; Actualizo color
    j salto3
salto4: halt