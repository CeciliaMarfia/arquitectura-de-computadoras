.data
a: .double 1.3, 3.5, 5.8, 1.9, 2.7
b: .double 7.1, 3.4, 9.0, 1.0, 5.8
c: .double 2.3, 8.2, 0.5, 1.1, 2.9
res: .double 0.0, 0.0, 0.0, 0.0, 0.0

.code
dadd $s0, $zero, $zero ; $s0 = desplazamiento
daddi $s1, $zero, 5 ; $s1 = cantidad de elementos

loop: l.d f1, a($s0) ; Tomo el elemento de a
    l.d f2, b($s0) ; Tomo el elemento de a
    l.d f3, c($s0) ; Tomo el elemento de a
    jal calcular
    s.d f4, res($s0)
    daddi $s1, $s1, -1 ; Decremento la cantidad de elementos a calcular
    daddi $s0, $s0, 8 ; Avanzo a la siguiente posicion
    bnez $s1, loop; Mientras $s1 no sea 0, itero
halt

calcular: sub.d f5, f1, f3 ; f5 = a - c
    mul.d f2, f2, f2 ; b ^ 2
    div.d f4, f5, f2 ; (a - c) / b ^ 2
    jr r31 ; Vuelvo