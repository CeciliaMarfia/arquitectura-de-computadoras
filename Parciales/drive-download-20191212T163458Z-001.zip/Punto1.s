.data
A: .word 4
B: .word 5

.code
lb r1, A(r0)
lb r2, B(r0)
loop: daddi r2, r2, -1
    bnez r2, loop
dsll r1, r1, 1
halt