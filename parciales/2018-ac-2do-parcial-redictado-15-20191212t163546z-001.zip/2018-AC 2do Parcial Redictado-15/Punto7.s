.data
coorX: .byte 10
coorY: .byte 20
color: .byte 255, 0, 0, 0
control: .word32 0x10000
data: .word32 0x10008

.code
; Cargo CONTROL y DATA en $s6 y $s7 respecticamente
lwu $s6, control($zero)
lwu $s7, data($zero)

lb $s0, coorX($zero) ; Cargo en $s0 el valor de la variable coordX
sb $s0, 5($s7) ; Cargo en la posicion DATA + 5 la coordenada X

lb $s1, coorY($zero) ; Cargo en $s1 el valor de la variable coordY
sb $s1, 4($s7) ; Cargo en la posicion DATA + 5 la coordenada Y

lw $s2, color($zero) ; Cargo en $s1 el valor de la variable color
sw $s2, 0($s7) ; Cargo en la posicion DATA los 4 bytes del color

; Grafico: mando a control el 5
daddi $t0, $0, 5
sd $t0, 0($s6)
halt